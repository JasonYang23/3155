package edu.colorado.csci3155.project1

import org.scalatest.FunSuite

class RecitationTest extends FunSuite{
    test("PushNumI") {
        val instructions = List(PushNumI(5))
        val (res, stack) = StackMachineEmulator.emulateSingleInstruction(instructions)
        assert(stack.head == 5)
    }
    test("Pop works on nonempty"){
        
        val Instruction = PopI
        val (res,stack)=StackMachineEmulator.emulateSingleInstruction(instructions)
        assert(res.isEmpty)

    }

}